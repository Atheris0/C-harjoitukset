﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace Sikanoppa
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool isPlayer1Human = false;
            bool isPlayer2Human = false;

            int total1 = 0;
            int total2 = 0;
            Random random = new Random();
            int rollsTotal = 0;
            bool gameOver = false;
            string answer;
            int turn = 1;

            Console.WriteLine("Do you want to start a new game (N) or load the previous game (L)?");
            string startOption = Console.ReadLine().ToUpper();

            if (startOption == "L")
            {
                // Load the saved game state
                Console.WriteLine("Loading the previous game...");
                LoadGameState(out total1, out total2, out turn);
            } else
            {
                Console.WriteLine("Starting new game...");
            }

            // Asking first are the players human or computer
            Console.WriteLine("Is Player1 human? Y/N");
            string isHuman1 = Console.ReadLine().ToUpper();
            if (isHuman1 == "Y")
            {
                isPlayer1Human = true;
            }
            Console.WriteLine("Is Player2 human? Y/N");
            string isHuman2 = Console.ReadLine().ToUpper();
            if (isHuman2 == "Y")
            {
                isPlayer2Human = true;
            }

            // Let the games begin
            while (gameOver == false)
            {
                // Total points should reach to 100
                while (total1 < 100 && total2 < 100)
                {

                    Console.WriteLine($"Player1 total points: {total1}");
                    Console.WriteLine($"Player2 total points: {total2}");
                    Console.WriteLine("...\nRolling the die");
                    Console.Write(".");
                    System.Threading.Thread.Sleep(200);
                    Console.Write(".");
                    System.Threading.Thread.Sleep(200);
                    Console.WriteLine(".");
                    System.Threading.Thread.Sleep(200);
                    int rolledDie = random.Next(1, 7);
                    if (rolledDie == 1)
                    {
                        Console.WriteLine("Haa haa rolled 1! Skipping the turn\n");
                        rollsTotal = 0;
                        //Checking the turns
                        if (turn == 1)
                        {
                            turn = 2;
                            Console.WriteLine("Player2's turn\n");
                        }
                        else
                        {
                            turn = 1;
                            Console.WriteLine("Player1's turn\n");
                        }
                        break;
                    }
                    else
                    {
                        Console.WriteLine($"You rolled: {rolledDie}");
                        rollsTotal += rolledDie;
                        Console.WriteLine($"Your total points this round: {rollsTotal}");
                        // Asking if the player wants to bank the points or continue rolling
                        Console.WriteLine("Do you want to bank the points? Y/N");
                        if (turn == 1)
                        {
                            //If player is computer this will choose
                            if (isPlayer1Human == false)
                            {
                                int computersChoice = random.Next(1, 3);
                                if (computersChoice == 1)
                                {
                                    answer = "Y";
                                }
                                else
                                {
                                    answer = "N";
                                }
                            }
                            //If player is human they will enter the answer
                            else
                            {
                                answer = Console.ReadLine().ToUpper();
                            }
                        }
                        else
                        {
                            //If player is computer this will choose
                            if (isPlayer2Human == false)
                            {
                                int computersChoice = random.Next(1, 3);
                                if (computersChoice == 1)
                                {
                                    answer = "Y";
                                }
                                else
                                {
                                    answer = "N";
                                }
                            }
                            //If player is human they will enter the answer
                            else
                            {
                                answer = Console.ReadLine().ToUpper();
                            }
                        }


                        //Checking the answer
                        if (answer == "Y")
                        {
                            if (turn == 1)
                            {
                                total1 += rollsTotal;
                            }
                            else
                            {
                                total2 += rollsTotal;
                            }

                            Console.WriteLine($"You banked the points. Rolls total points: {rollsTotal}\n");
                            rollsTotal = 0;
                            //Checking the turns
                            if (turn == 1)
                            {
                                turn = 2;
                                Console.WriteLine("Player2's turn\n");
                            }
                            else
                            {
                                turn = 1;
                                Console.WriteLine("Player1's turn\n");
                            }
                        }
                        // Save the game state to a file
                        SaveGameState(total1, total2, turn);

                    }
                }
                //If the total reaches the 100 game ends
                if (total1 >= 100 || total2 >= 100)
                {
                    gameOver = true;
                }

            }
            if (turn == 1)
            {
                Console.WriteLine("Player2 won!");
            }
            else
            {
                Console.WriteLine("Player1 won!");
            }



            Console.ReadLine();
        }
        static void SaveGameState(int total1, int total2, int turn)
        {
            using (StreamWriter writer = new StreamWriter("gamestate.txt"))
            {
                writer.WriteLine(total1);
                writer.WriteLine(total2);
                writer.WriteLine(turn);
            }
        }
        static void LoadGameState(out int total1, out int total2, out int turn)
        {
            total1 = 0;
            total2 = 0;
            turn = 1;
            if (File.Exists("gamestate.txt"))
            {
                using (StreamReader reader = new StreamReader("gamestate.txt"))
                {
                    int.TryParse(reader.ReadLine(), out total1);
                    int.TryParse(reader.ReadLine(), out total2);
                    int.TryParse(reader.ReadLine(), out turn);
                }
            }
        }
    }
}
